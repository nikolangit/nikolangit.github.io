# Maze game

Simple maze game.

![maze-game-screenshot](screenshot.png)
