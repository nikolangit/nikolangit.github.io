function stopwatch() {
    ms++;
    if (ms >= 100) {
        ms = 0;
        s++;
    }

    if (s >= 60) {
        s = 0;
        m++;
    }

    if (m >= 60) {
        m = 0;
        h++;
    }

    if (h >= 24) {
        h = 0;
        d++;
    }

    elms.stopwatch.time.textContent = d
        + ' ' + (h < 10 ? '0' : '') + h
        + ':' + (m < 10 ? '0' : '') + m
        + ':' + (s < 10 ? '0' : '') + s
        + '.' + (ms % 100 < 10 ? '0' : '') + (ms % 100)
    ;
}

function play_pause_stopwatch() {
    pause = !pause;

    if (pause) {
        clearInterval(interval);
        elms.stopwatch.btnPlay.children[0].className = 'fa-solid fa-play';

    } else {
        interval = setInterval(stopwatch, 10);
        elms.stopwatch.btnPlay.children[0].className = 'fa-solid fa-pause';
    }
}

function stop_stopwatch() {
    clearInterval(interval);

    d = h = m = s = ms = 0;
    
    elms.stopwatch.time.textContent              = '0 00:00:00.00';
    elms.stopwatch.btnPlay.children[0].className = 'fa-solid fa-play';
}

function close_modal() {
    if (elms.modal.dataset.active == '1') {
        elms.modal.dataset.active = '0';
    }
}

function change_theme_btn() {
    elms.modal.dataset.active = '1';
}

function change_theme(theme_data) {
    for (let property in theme_data) {
        let css_property = '--' + property.replace('_', '-');

        root.style.setProperty(css_property, '#' + theme_data[property]);
    }
}

const elms = {
        title: document.getElementById('title'),
        modal: document.getElementById('modal'),
        stopwatch: {
            time   : document.getElementById('stopwatch-time'),
            btnPlay: document.getElementById('stopwatch-btn-play-pause'),
            btnStop: document.getElementById('stopwatch-btn-stop'),
        },
        theme: {
            btn: document.getElementById('theme-btn'),
            example: {
                holder    : document.getElementById('theme-example-holder'),
                text      : document.getElementById('theme-example-text'),
                btnPrimary: document.getElementById('theme-example-btn-primary'),
                btn       : document.getElementById('theme-example-btn'),
            },
            list: document.getElementById('themes-list')
        }
    },
    root = document.documentElement
;

let d = h = m = s = ms = theme_list_elm_active = 0,
    pause = true,
    interval
;

for (let i = 0;  i < themes.length;  i++) {
    let theme_list_elm = document.createElement('div'),
        theme_data     = themes[i]
    ;

    theme_list_elm.textContent = i + 1;
    theme_list_elm.className   = 'theme-item' + (i ? '' : ' active');

    theme_list_elm.style.backgroundColor = '#' + theme_data.bg;
    theme_list_elm.style.color           = '#' + theme_data.primary_bg;
    theme_list_elm.style.borderColor     = '#' + theme_data.text;

    theme_list_elm.addEventListener('mouseover', () => {
        elms.theme.example.holder.style.backgroundColor = '#' + theme_data.bg;
        elms.theme.example.holder.style.color           = '#' + theme_data.text;

        elms.theme.example.btnPrimary.style.backgroundColor = '#' + theme_data.primary_bg;
        elms.theme.example.btnPrimary.style.color           = '#' + theme_data.primary_text;

        elms.theme.example.btn.style.backgroundColor = '#' + theme_data.btn_bg;
        elms.theme.example.btn.style.color           = '#' + theme_data.btn_text;
    }, true);

    theme_list_elm.addEventListener('click', () => {
        change_theme(theme_data);

        elms.theme.list.children[theme_list_elm_active].classList.remove('active');
        elms.theme.list.children[i].classList.add('active');

        theme_list_elm_active = i;
    }, true);

    elms.theme.list.appendChild(theme_list_elm);
}

elms.theme.btn.addEventListener('click', change_theme_btn, true);

elms.stopwatch.btnPlay.addEventListener('click', play_pause_stopwatch, true);
elms.stopwatch.btnPlay.addEventListener('keyup', play_pause_stopwatch, true);
elms.stopwatch.btnStop.addEventListener('click', stop_stopwatch, true);

window.onclick = (e) => {
    if (e.target == elms.modal) {
        close_modal();
    }

    document.activeElement.blur();
}

window.addEventListener('keyup', (e) => {
    switch (e.key) {
        // Exit modals.
        case 'Esc':
        case 'Escape':
            close_modal();
            break;

        // Play/pause.
        case ' ':
        case 'Space':
            play_pause_stopwatch();
            break;

        // Stop.
        case 's':
        case 'S':
            stop_stopwatch();
            break;

        // Change theme.
        case 't':
        case 'T':
            change_theme_btn();
            break;

        default:
            return;
    }
});
