<?php

return [
    'author' => 'Nikola Nikolić',
    'errors' => [
        'validation' => [
            'title' => 'Vrednost polja nije važeća!',
            'msg'   => 'Polje "%s" ne sadrži važeću vrednost.',
        ],
        'api_not_found' => [
            'title' => 'API nije pronađen!',
            'msg'   => 'Traženi API nije pronađen.',
        ],
        'http_not_found' => [
            'title' => 'HTTP nije pronađen!',
            'msg'   => 'HTTP metod za ovaj API nije pronađen.',
        ],
        'invalid_json' => [
            'title' => 'Serverska greška!',
            'msg'   => 'Dobijeni podaci nisu odgovarajući.',
        ]
    ],
    'warnings' => [
        'validation' => [
            'missing_key' => [
                'title' => 'Polje nije definisano!',
                'msg'	=> 'Nedostaje polje "%s".',
            ],
            'invalid_key_type' => [
                'title' => 'Vrednost polja nije odgovarajuća!',
                'msg'	=> 'Polje "%s" nema odgovarajuću vrednost.',
            ],
        ],
    ],
    'success' => [
        'changed_lang' => [
            'title' => 'Jezik je promenjen.',
            'msg'   => "Trenutni jezik je '%s'.\nStranica će se osvežiti za 3 sekunde.",
        ],
    ],
    'info' => [

    ],
    'langs' => [
        'en'      => 'Engleski',
        'sr-latn' => 'Srpski (latinica)',
        'sr-cyrl' => 'Srpski (ćirilica)',
    ],
    'page_titles' => [
        '404' => 'Stranica nije pronađena',
        'home' => 'Početna',
        'modules' => [
            'photos'  => 'Slike',
            'cameras' => 'Kamere',
        ],
        'methods' => [
            'cameras' => [
                'get_brands'       => 'Brendovi kamera',
                'get_brand_models' => 'Marke brenda kamera',
            ],
            'photos' => [
                'availlable_sizes' => 'Dozvoljene veličine',
                'get_recent'       => 'Nedavne fotografije',
                'get_sizes'        => 'Veličine fotografija',
            ],
        ],
    ],
    'flickr' => [
        'errors' => [
            'code_status' => [
                '1' => [
                    'title' => 'Mini-token nije pronađen!',
                    'msg'   => 'Prosleđeni mini-token nije važeći.',
                ],
                '2' => [
                    'title' => 'Dozvola odbijena!',
                    'msg'   => 'Korisnik nema dozvolu da pogleda fotografiju.',
                ],
                '95' => [
                    'title' => 'SSL je obavezan!',
                    'msg'   => 'SSL je obavezan da bi se pristupilo Flickr API-jima.',
                ],
                '96' => [
                    'title' => 'Nevažeći potpis!',
                    'msg'   => 'Poslati potpis je nevažeči.',
                ],
                '97' => [
                    'title' => 'Nevažeći detalji za prijavu!',
                    'msg'   => 'Podaci za prijavu ili prosledeni token za potvrdu su nevažeći.',
                ],
                '98' => [
                    'title' => 'Prijava nije uspela / nevažeći token za potvrdu!',
                    'msg'   => 'Podaci za prijavu ili prosledeni token za potvrdu su nevažeći.',
                ],
                '99' => [
                    'title' => 'Korisnik nije prijavljen / nedovoljne dozvole!',
                    'msg'   => 'Nedovoljne dozvole. Metod zahteva privilegije čitanja, nijedna nije dodeljena.',
                ],
                '100' => [
                    'title' => 'Neispravan API ključ!',
                    'msg'   => 'Prosleđeni API ključ nije važeći ili je istekao.',
                ],
                '105' => [
                    'title' => 'Usluga trenutno nije dostupna!',
                    'msg'   => 'Tražena usluga je privremeno nedostupna.',
                ],
                '106' => [
                    'title' => 'Operacija upisivanja nije uspela!',
                    'msg'   => 'Zahtevana operacija nije uspela zbog privremenog problema.',
                ],
                '111' => [
                    'title' => 'Format "xxx" nije pronađen!',
                    'msg'   => 'Traženi format nije pronađen.',
                ],
                '112' => [
                    'title' => 'Metod "xxx" nije pronađen!',
                    'msg'   => 'Traženi method nije pronađen.',
                ],
                '114' => [
                    'title' => 'Nevažeća SOAP koverta!',
                    'msg'   => 'Poslata SOAP koverta u zahtevu nije mogla da se raščlani.',
                ],
                '115' => [
                    'title' => 'Neispravan poziv XML-RPC metoda!',
                    'msg'   => 'Traženi XML-RPC dokument nije mogao da se paščlani.',
                ],
                '116' => [
                    'title' => 'Pronađen je loš URL!',
                    'msg'   => 'Jedan ili više argumenata unutar URL-a je korišćen za zloupotrebu Flickr-a.',
                ],
            ],
        ],
        'sizes' => [
            'original'   => 'Original',
            'square'     => 'Kvadrat',
            'lg_square'  => 'Veliki kvadrat',
            'thumbnail'  => 'Thumbnail',
            'small'      => 'Mala',
            'small_320'  => 'Mala 320',
            'small_400'  => 'Mala 400',
            'medium'     => 'Srednja',
            'medium_640' => 'Srednja 640',
            'medium_800' => 'Srednja 800',
            'large'      => 'Velika',
            'large_1600' => 'Velika 1600',
            'large_2048' => 'Velika 2048',
            'x_large'    => 'X-Velika 3K',
        ],
        'labels' => [
            'id'              => 'ID',
            'photo_id'        => 'ID fotografije',
            'user_id'         => 'ID korisnika',
            'api_key'         => 'API ključ',
            'name'            => 'Naziv',
            'brand'           => 'Brend',
            'extras'          => 'Dodaci',
            'per_page'        => 'Po stranici',
            'page'            => 'Stranica',
            'sort'            => 'Sortiranje',
            'asc'             => 'Uzlazni',
            'desc'            => 'Silazni',
            'order_by_name'   => 'Sortirati po imenu',
            'order_by_dir'    => 'Pravac sortiranja',
            'img_size_name'   => 'Naziv veličine slike',
            'img_size'        => 'Veličina slike',
            'img'             => 'Slika',
            'img_sm'          => 'Mala slika',
            'img_lg'          => 'Velika slika',
            'size'            => 'Veličina',
            'ratio'           => 'Razmera slike (x:y)',
            'is_public'       => 'Javno',
            'server'          => 'Naziv servera',
            'title'           => 'Naslov',
            'faves'           => 'Faves',
            'views'           => 'Pogledano',
            'comments'        => 'Komentari',
            'interesting'     => 'Interesantno',
            'description'     => 'Opis',
            'license'         => 'Licenca',
            'date_upload'     => 'Datum otpremanja',
            'date_taken'      => 'Datum kreiranja',
            'owner_name'      => 'Ime vlasnika',
            'icon_server'     => 'Ikonica servera',
            'original_format' => 'Originalni format',
            'last_update'     => 'Poslednje otpremanje',
            'geo'             => 'Geološki podaci',
            'tags'            => 'Oznake',
            'machine_tags'    => 'Mašinske oznake',
            'o_dims'          => 'O dims',
            'media'           => 'Media',
            'path_alias'      => 'Alias putanje',
            'url_sq'          => 'Putanja kockaste slike',
            'url_t'           => 'Putanja thumbnail slike',
            'url_s'           => 'Putanja male slike',
            'url_q'           => 'Putanja velike kockaste slike',
            'url_m'           => 'Putanja srednje slike',
            'url_n'           => 'Putanja male 320px slike',
            'url_z'           => 'Putanja srednje 640px slike',
            'url_c'           => 'Putanja srednje 800px slike',
            'url_l'           => 'Putanja velike slike',
            'url_o'           => 'Putanja originalne slike',
            'total_rows'      => 'Ukupno redova',
            'get_data'        => 'Uzmi podatke',
        ],
        'fields' => [
            'api_key'  => 'Vaš API kluč aplikacije.',
            'extras'   => 'Lista dodatnih informacija razdvojenih zarezima za preuzimanje za svaki vraćeni zapis. Trenutno podržana polja su: %s.',
            'per_page' => 'Broj fotografija koje treba vratiti po stranici. Ako je ovaj argument izostavljen, podrazumevano je 100 (na Flickr-u). Dozvoljeni opseg na ovom sajtu je od %d do %d.',
            'page'     => 'Stranica rezultata za vraćanje. Ako je ovaj argument izostavljen, podrazumevano je 1. Dozvoljeni opseg na ovoj lokaciji je od %d do %d.',
            'photo_id' => 'ID fotografije od koje će se uzimati podaci.',
            'user_id'  => 'NSID korisnika za korišćenje liste galerija. Ako ništa nije navedeno, pretpostavlja se korisnik koji poziva.',
            'sort'     => 'Redosled sortiranja. Jedan od %s. Podrazumevano na %s.',
            'brand'    => 'ID od zahtevanog brenda.',
        ],
        'method_info' => [
            'cameras' => [
                'getBrandModelsInfo' => 'Preuzmite sve modele za datu marku fotoaparata.',
                'getBrandsInfo'      => 'Vraća sve marke kamera za koje Flickr zna.',
            ],
            'photos' => [
                'availlableSizesInfo' => 'Vraća sve dozvoljene veličine fotografija.',
                'getRecentInfo'       => 'Vraća listu najnovijih javnih fotografija otpremljenih na Flickr-u.',
                'getSizesInfo'        => 'Vraća dostupne veličine za fotografiju. Korisnik koji poziva mora imati dozvolu da vidi fotografiju.',
            ],
        ],
    ],
];
