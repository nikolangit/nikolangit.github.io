<?php

return [
    'author' => 'Nikola Nikolić',
    'errors' => [
        'validation' => [
            'title' => 'Field value is not valid!',
            'msg'   => 'Field "%s" has not valid value.',
        ],
        'api_not_found' => [
            'title' => 'API not found!',
            'msg'   => 'The requested API is not found.',
        ],
        'http_not_found' => [
            'title' => 'HTTP method error!',
            'msg'   => 'The HTTP method for this API is not valid.',
        ],
        'invalid_json' => [
            'title' => 'Server error!',
            'msg'   => 'Invalid response data.',
        ]
    ],
    'warnings' => [
        'validation' => [
            'missing_key' => [
                'title' => 'Field is not set!',
                'msg'	=> 'Missing field "%s".',
            ],
            'invalid_key_type' => [
                'title' => 'Field type is not valid!',
                'msg'	=> 'Field "%s" is not a valid type.',
            ],
        ],
    ],
    'success' => [
        'changed_lang' => [
            'title' => 'Language is changed.',
            'msg'   => "Current language is '%s'.\nPage will reload in 3 seconds.",
        ],
    ],
    'info' => [

    ],
    'langs' => [
        'en'      => 'English',
        'sr-latn' => 'Serbian (latin)',
        'sr-cyrl' => 'Serbian (cyrillic)',
    ],
    'page_titles' => [
        '404' => 'Page not found',
        'home' => 'Homepage',
        'modules' => [
            'photos'  => 'Photos',
            'cameras' => 'Cameras',
        ],
        'methods' => [
            'cameras' => [
                'get_brands'       => 'Camera brands',
                'get_brand_models' => 'Camera brands models',
            ],
            'photos' => [
                'availlable_sizes' => 'Availlable sizes',
                'get_recent'       => 'Recent photos',
                'get_sizes'        => 'Photo sizes',
            ],
        ],
    ],
    'flickr' => [
        'errors' => [
            'code_status' => [
                '1' => [
                    'title' => 'Mini-token not found!',
                    'msg'   => 'The passed mini-token was not valid.',
                ],
                '2' => [
                    'title' => 'Permission denied!',
                    'msg'   => 'The calling user does not have permission to view the photo.',
                ],
                '95' => [
                    'title' => 'SSL is required!',
                    'msg'   => 'SSL is required to access the Flickr API.',
                ],
                '96' => [
                    'title' => 'Invalid signature!',
                    'msg'   => 'The passed signature was invalid.',
                ],
                '97' => [
                    'title' => 'Invalid login details!',
                    'msg'   => 'The login details or auth token passed were invalid.',
                ],
                '98' => [
                    'title' => 'Login failed / Invalid auth token!',
                    'msg'   => 'The login details or auth token passed were invalid.',
                ],
                '99' => [
                    'title' => 'User not logged in / Insufficient permissions!',
                    'msg'   => 'Insufficient permissions. Method requires read privileges, none granted.',
                ],
                '100' => [
                    'title' => 'Invalid API Key!',
                    'msg'   => 'The API key passed was not valid or has expired.',
                ],
                '105' => [
                    'title' => 'Service currently unavailable!',
                    'msg'   => 'The requested service is temporarily unavailable.',
                ],
                '106' => [
                    'title' => 'Write operation failed!',
                    'msg'   => 'The requested operation failed due to a temporary issue.',
                ],
                '111' => [
                    'title' => 'Format "xxx" not found!',
                    'msg'   => 'The requested response format was not found.',
                ],
                '112' => [
                    'title' => 'Method "xxx" not found!',
                    'msg'   => 'The requested method was not found.',
                ],
                '114' => [
                    'title' => 'Invalid SOAP envelope!',
                    'msg'   => 'The SOAP envelope send in the request could not be parsed.',
                ],
                '115' => [
                    'title' => 'Invalid XML-RPC Method Call!',
                    'msg'   => 'The XML-RPC request document could not be parsed.',
                ],
                '116' => [
                    'title' => 'Bad URL found!',
                    'msg'   => 'One or more arguments contained a URL that has been used for abuse on Flickr.',
                ],
            ],
        ],
        'sizes' => [
            'original'   => 'Original',
            'square'     => 'Square',
            'lg_square'  => 'Large Square',
            'thumbnail'  => 'Thumbnail',
            'small'      => 'Small',
            'small_320'  => 'Small 320',
            'small_400'  => 'Small 400',
            'medium'     => 'Medium',
            'medium_640' => 'Medium 640',
            'medium_800' => 'Medium 800',
            'large'      => 'Large',
            'large_1600' => 'Large 1600',
            'large_2048' => 'Large 2048',
            'x_large'    => 'X-Large 3K',
        ],
        'labels' => [
            'id'              => 'ID',
            'photo_id'        => 'Photo ID',
            'user_id'         => 'User ID',
            'api_key'         => 'API key',
            'name'            => 'Name',
            'brand'           => 'Brand',
            'extras'          => 'Extras',
            'per_page'        => 'Per page',
            'page'            => 'Page',
            'sort'            => 'Sort',
            'asc'             => 'Ascending',
            'desc'            => 'Descending',
            'order_by_name'   => 'Order by name',
            'order_by_dir'    => 'Order by direction',
            'img_size_name'   => 'Image size name',
            'img_size'        => 'Image size',
            'img'             => 'Image',
            'img_sm'          => 'Small image',
            'img_lg'          => 'Large image',
            'size'            => 'Size',
            'ratio'           => 'Image ratio (x:y)',
            'is_public'       => 'Public',
            'server'          => 'Server name',
            'title'           => 'Title',
            'faves'           => 'Faves',
            'views'           => 'Views',
            'comments'        => 'Comments',
            'interesting'     => 'Interesting',
            'description'     => 'Description',
            'license'         => 'License',
            'date_upload'     => 'Date uploaded',
            'date_taken'      => 'Date taken',
            'owner_name'      => 'Owner\'s name',
            'icon_server'     => 'Server icon',
            'original_format' => 'Original format',
            'last_update'     => 'Last updated',
            'geo'             => 'Geological data',
            'tags'            => 'Tags',
            'machine_tags'    => 'Machine tags',
            'o_dims'          => 'O dims',
            'media'           => 'Media',
            'path_alias'      => 'Path alias',
            'url_sq'          => 'Square image path',
            'url_t'           => 'Thumbnail image path',
            'url_s'           => 'Small image path',
            'url_q'           => 'Large square image path',
            'url_m'           => 'Medium image path',
            'url_n'           => 'Small 320px image path',
            'url_z'           => 'Medium 640px image path',
            'url_c'           => 'Medium 800px image path',
            'url_l'           => 'Large image path',
            'url_o'           => 'Original image path',
            'total_rows'      => 'Total rows',
            'get_data'        => 'Get data',
        ],
        'fields' => [
            'api_key'  => 'Your API application key.',
            'extras'   => 'A comma-delimited list of extra information to fetch for each returned record. Currently supported fields are: %s.',
            'per_page' => 'Number of photos to return per page. If this argument is omitted, it defaults to 100 (on Flickr). The allowed range on this site is from %d to %d.',
            'page'     => 'The page of results to return. If this argument is omitted, it defaults to 1. The allowed range on this site is from %d to %d.',
            'photo_id' => 'The ID of the photo to fetch size information for.',
            'user_id'  => 'The NSID of the user to get a galleries list for. If none is specified, the calling user is assumed.',
            'sort'     => 'The sort order. One of %s. Defaults to %s.',
            'brand'    => 'The ID of the requested brand.',
        ],
        'method_info' => [
            'cameras' => [
                'getBrandModelsInfo' => 'Retrieve all the models for a given camera brand.',
                'getBrandsInfo'      => 'Returns all the brands of cameras that Flickr knows about.',
            ],
            'photos' => [
                'availlableSizesInfo' => 'Returns all available sizes for images.',
                'getRecentInfo'       => 'Returns a list of the latest public photos uploaded to Flickr.',
                'getSizesInfo'        => 'Returns the available sizes for a photo. The calling user must have permission to view the photo.',
            ],
        ],
    ],
];
