/**
 * It created AJAX request.
 * 
 * @author Nikola Nikolić <rogers94kv@gmail.com>
 * @param  {string}   method   HTTP method.
 * @param  {string}   api      API's request.
 * @param  {mixed}    data     Data to send.
 * @param  {callback} callback Callback function.
 * @return {void}
 */
function ajax(method = 'PUT', api = '', data, callback) {
    if (!regexApiPath.test(api)) {
        return;
    }

    if (!((method == 'GET')  ||  (method == 'PUT'))) {
        return;
    }

    let xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            elmOverlay.dataset.active = 0;

            try {
                let json = JSON.parse(this.responseText);
                callback(json);
            } catch (e) {
                return;
            }
        }
    }
    xhttp.open(method, '/' + PROJECT_API_URL + api, true);
    xhttp.setRequestHeader('Content-Type', 'application/json');
    xhttp.send(JSON.stringify(data));
}

/**
 * It display's toastr.
 * 
 * @author Nikola Nikolić <rogers94kv@gmail.com>
 * @param  {object} data Toastr data.
 * @return {void}
 */
function displayToastr(data = {}) {
    if ((data.toastr == undefined) || (data.toastr == false)) {
        return;
    }

    let bg    = 'success',
        color = 'white',
        icon  = 'check-circle'
    ;

    switch (data.type) {
        case MESSAGE_TYPE_ERROR:
            bg    = 'danger';
            color = 'white';
            icon  = 'exclamation-triangle';
            break;

        case MESSAGE_TYPE_WARNING:
            bg    = 'warning';
            color = 'dark';
            icon  = 'exclamation';
            break;

        case MESSAGE_TYPE_INFO:
            bg    = 'info';
            color = 'white';
            icon  = 'info-circle';
            break;

        default:
            break;
    }

    let toast       = document.createElement('div'),
        toastHeader = document.createElement('div'),
        toastIcon   = document.createElement('i'),
        toastStrong = document.createElement('strong'),
        toastButton = document.createElement('button'),
        toastBody   = document.createElement('div')
    ;

    // Toast head.
    toastHeader.className = 'toast-header';

    toast.classList  = 'toast align-items-center bg-' + bg + ' text-' + color + ' border-0 show';

    toastIcon.className = 'fa fa-' + icon + ' me-2';
    toastHeader.appendChild(toastIcon);

    toastStrong.className   = 'me-auto';
    toastStrong.textContent = data.title;
    toastHeader.appendChild(toastStrong);

    toastButton.className         = 'btn-close';
    toastButton.dataset.bsDismiss = 'toast';
    toastButton.ariaLabel         = 'Close';
    toastButton.onclick = function () {
        toast.remove();
    }
    toastHeader.appendChild(toastButton);

    // Toast body.
    toastBody.className = 'toast-body';
    toastBody.innerHTML = data.msg;

    toast.appendChild(toastHeader);
    toast.appendChild(toastBody);

    elmToastContainer.appendChild(toast);

    setTimeout(() => {
        toast.classList.remove('show');

        setTimeout(() => {
            toast.remove();
        }, 2000);
    }, 7000);
}

/**
 * It returns formated datetime from UNIX timestamp.
 * 
 * @author Nikola Nikolić <rogers94kv@gmail.com>
 * @param  {int}    unixTimestamp UNIX timestamp.
 * @return {string}               Formated datetime.
 */
function fromUnixTimestampToDatetimeFormat(unixTimestamp) {
    let date = new Date(Number(unixTimestamp) * 1000),
        datetimeData = [
            date.getDate(),
            date.getMonth() + 1,
            date.getFullYear(),
            date.getHours(),
            date.getMinutes(),
            date.getSeconds()
        ]
    ;

    datetimeData = datetimeData.map(item => {
        return item < 10
            ? '0' + item
            : item
        ;
    })

    return datetimeData.slice(0, 3).join('.')
        + ' '
        + datetimeData.slice(3).join(':')
    ;
}

const regexApiPath = /^[a-z]+[a-z\-\/]+[a-z]$/;

const elmToastContainer = document.getElementsByClassName('toast-container')[0],
    elmChooseLang       = document.getElementById('choose-lang'),
    elmOverlay          = document.getElementById('overlay')
;

elmChooseLang.onchange = function () {
    elmOverlay.dataset.active = 1;

    ajax(
        'PUT',
        'change/lang',
        {
            lang: this.value
        },
        function (data) {
            displayToastr(data);

            setTimeout(() => {
                window.location.reload();
            }, 3000);
        }
    );
}
