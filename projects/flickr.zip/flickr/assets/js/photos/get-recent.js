const API = 'photos/recent/list';

const elmGetData    = document.getElementById('get-data'),
    elmRenderHolder = document.getElementById('render-holder'),
    elmTotalRows    = document.getElementById('total-rows')
;

elmGetData.onclick = function () {
    let elmFormItems = document.getElementsByClassName('form-items'),
        obj = {}
    ;

    for (let formItem of elmFormItems) {
        obj[formItem.id] = formItem.value;
    }

    elmOverlay.dataset.active = 1;

    ajax(
        'PUT',
        API,
        obj,
        function (data) {
            displayToastr(data);

            if (data.type == MESSAGE_TYPE_SUCCESS) {
                while (elmRenderHolder.firstChild) {
                    elmRenderHolder.firstChild.remove();
                }

                let table   = document.createElement('table'),
                    thead   = document.createElement('thead'),
                    tbody   = document.createElement('tbody'),
                    tr      = document.createElement('tr'),
                    th      = document.createElement('th'),
                    td      = document.createElement('td'),
                    counter = 0
                ;

                th.textContent = '#';
                tr.appendChild(th);

                for (let key in data.labels) {
                    th = document.createElement('th');
                    th.textContent = data.labels[key];
                    tr.appendChild(th);
                }

                thead.appendChild(tr);

                for (let i in data.data) {
                    tr = document.createElement('tr');
                    th = document.createElement('th');

                    th.textContent = ++counter;
                    tr.appendChild(th);

                    for (let key in data.data[i]) {
                        td = document.createElement('td');

                        switch (key) {
                            case 'is_public':
                                let icon = document.createElement('i');

                                if (data.data[i].is_public) {
                                    td.className   = 'text-success';
                                    icon.className = 'fa fa-eye';
                                } else {
                                    td.className   = 'text-danger';
                                    icon.className = 'fa fa-eye-slash';
                                }            

                                td.appendChild(icon);
                                break;

                            case 'date_upload':
                            case 'last_update':
                                td.textContent = fromUnixTimestampToDatetimeFormat(data.data[i][key]);
                                break;

                            case 'date_taken':
                                td.textContent = data.data[i][key].replace(/(\d+)-(\d+)-(\d+)( .+)/, '$3.$2.$1$4');
                                break;

                            case 'geo':
                                td.textContent = data.data[i][key].lat + ',' + data.data[i][key].lng;
                                break;

                            case 'url_sq':
                            case 'url_t':
                            case 'url_s':
                            case 'url_q':
                            case 'url_m':
                            case 'url_n':
                            case 'url_z':
                            case 'url_c':
                            case 'url_l':
                            case 'url_o':
                                let img = document.createElement('img');

                                img.src = data.data[i][key];
                                img.alt = data.data[i].title;
                                img.onclick = function () {
                                    window.open(this.src);
                                }
                                td.appendChild(img);
                                break;

                            default:
                                td.textContent = data.data[i][key];
                                break;
                        }

                        tr.appendChild(td);
                    }

                    tbody.appendChild(tr);
                }

                elmTotalRows.textContent = counter;

                table.className = 'table table-sm table-striped table-hover';

                table.appendChild(thead);
                table.appendChild(tbody);

                elmRenderHolder.appendChild(table);
            }
        }
    );
}
