const API = 'photos/available-sizes/list';

const elmGetData    = document.getElementById('get-data'),
    elmRenderHolder = document.getElementById('render-holder'),
    elmTotalRows    = document.getElementById('total-rows')
;

elmGetData.onclick = function () {
    elmOverlay.dataset.active = 1;

    ajax(
        'GET',
        API,
        {},
        function (data) {
            displayToastr(data);

            if (data.type == MESSAGE_TYPE_SUCCESS) {
                while (elmRenderHolder.firstChild) {
                    elmRenderHolder.firstChild.remove();
                }

                let table   = document.createElement('table'),
                    thead   = document.createElement('thead'),
                    tbody   = document.createElement('tbody'),
                    tr      = document.createElement('tr'),
                    th      = document.createElement('th'),
                    counter = 0
                ;

                th.textContent = '#';
                tr.appendChild(th);

                th = document.createElement('th');
                th.textContent = data.labels.name;
                tr.appendChild(th);

                th = document.createElement('th');
                th.textContent = data.labels.size;
                tr.appendChild(th);

                thead.appendChild(tr);

                for (let i in data.data) {
                    tr = document.createElement('tr');
                    th = document.createElement('th');

                    let td_id   = document.createElement('td'),
                        td_name = document.createElement('td')
                    ;

                    th.textContent = ++counter;
                    tr.appendChild(th);

                    td_id.textContent = data.data[i].name;
                    tr.appendChild(td_id);

                    td_name.textContent = data.data[i].size;
                    tr.appendChild(td_name);

                    tbody.appendChild(tr);
                }

                elmTotalRows.textContent = counter;

                table.className = 'table table-sm table-striped table-hover';

                table.appendChild(thead);
                table.appendChild(tbody);

                elmRenderHolder.appendChild(table);
            }
        }
    );
}
