const API = 'photos/sizes/list';

const elmGetData    = document.getElementById('get-data'),
    elmRenderHolder = document.getElementById('render-holder'),
    elmTotalRows    = document.getElementById('total-rows')
;

elmGetData.onclick = function () {
    let elmFormItems = document.getElementsByClassName('form-items'),
        obj = {}
    ;

    for (let formItem of elmFormItems) {
        obj[formItem.id] = formItem.value;
    }

    elmOverlay.dataset.active = 1;

    ajax(
        'PUT',
        API,
        obj,
        function (data) {
            displayToastr(data);

            if (data.type == MESSAGE_TYPE_SUCCESS) {
                while (elmRenderHolder.firstChild) {
                    elmRenderHolder.firstChild.remove();
                }

                let table   = document.createElement('table'),
                    thead   = document.createElement('thead'),
                    tbody   = document.createElement('tbody'),
                    tr      = document.createElement('tr'),
                    th      = document.createElement('th'),
                    td      = document.createElement('td'),
                    counter = 0
                ;

                th.textContent = '#';
                tr.appendChild(th);

                for (let key in data.labels) {
                    th = document.createElement('th');
                    th.textContent = data.labels[key];
                    tr.appendChild(th);
                }

                thead.appendChild(tr);

                for (let i in data.data) {
                    tr = document.createElement('tr');
                    th = document.createElement('th');

                    th.textContent = ++counter;
                    tr.appendChild(th);

                    for (let key in data.data[i]) {
                        td = document.createElement('td');

                        if (key == 'img_url') {
                            let img = document.createElement('img');

                            img.src = data.data[i][key];
                            img.alt = data.data[i].title;
                            img.onclick = function () {
                                window.open(this.src);
                            }
                            td.appendChild(img);

                        } else {
                            td.textContent = data.data[i][key];
                        }

                        tr.appendChild(td);
                    }

                    tbody.appendChild(tr);
                }

                elmTotalRows.textContent = counter;

                table.className = 'table table-sm table-striped table-hover';

                table.appendChild(thead);
                table.appendChild(tbody);

                elmRenderHolder.appendChild(table);
            }
        }
    );
}
