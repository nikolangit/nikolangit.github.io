<header>
    <nav class="navbar navbar-dark bg-dark text-light">
        <div class="container">
            <a class="navbar-brand" href="/"><?= PROJECT_NAME; ?></a>

            <div class="d-flex">
                <select id="choose-lang" class="form-select">
                    <?php
                        $langs = Language::list(true);
                        foreach ($langs as $code => $translation) :
                            $selected = Language::get() == $code
                                ? 'selected'
                                : ''
                            ;
                    ?>
                        <option value="<?= $code ?>" <?= $selected ?>>
                            <?= $translation ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </nav>
</header>
