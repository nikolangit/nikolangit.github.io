<?php

$pageData = View::loadPage(Request::uri());
if (isset($pageData['error'])
    || !file_exists($pageData['path'])
) {
    header('Location: /404');
    die();
}

?>
<!DOCTYPE html>
<html lang="<?= $pageData['lang']; ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= $pageData['desc']; ?>">
    <title><?= $pageData['title'] . ' | ' . PROJECT_NAME; ?></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/main.css">
    <script><?= View::appConstants(true); ?></script>
</head>
<body>

    <?php require_once 'header.php'; ?>

    <main class="container py-3">
        <?php if (preg_match('/index\.php$/', $pageData['path'])) : ?>
        <div class="row">
            <div class="col-md-12">
                <h1><?= $pageData['title']; ?></h1>

                <p><?= $pageData['desc']; ?></p>

                <?php require_once 'templates/list-pages.php'; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php require_once $pageData['path']; ?>
    </main>

    <!-- Toast -->
    <div class="toast-container position-absolute bottom-0 end-0 p-3"></div>
    <!-- ./Toast -->

    <?php require_once 'footer.php'; ?>

    <div id="overlay" data-active="0">
        <i class="fa fa-spinner"></i>
    </div>

    <script src="/assets/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/main.js"></script>
    <?php if (isset($pageData['path']) && !is_null($pageData['path'])) : ?>
        <script src="/assets/js/<?= preg_replace('/view\/(.+)\.php$/', '$1.js', $pageData['path']); ?>"></script>
    <?php endif; ?>

</body>
</html>
