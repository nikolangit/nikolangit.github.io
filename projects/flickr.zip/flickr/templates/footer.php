<footer class="bg-dark text-light">
    <div class="container">
        <div class="row">
            <div class="col-md-12 py-1 text-center">&copy;Copyrights <?= translate('author'); ?></div>
        </div>
    </div>
</footer>
