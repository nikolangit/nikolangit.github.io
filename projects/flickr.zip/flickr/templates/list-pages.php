<?php

// Get template file name to load.
preg_match('/view\\/(\w+)\\//', $pageData['path'], $matched);
$moduleNameToGetMethods = isset($matched[1])
    ? $matched[1]
    : ''
;

// Get active methods for the certain module.
$activeMethods = Common::getActiveMethods($moduleNameToGetMethods);
foreach ($activeMethods as $moduleName => $methodsList) :
    if (($moduleNameToGetMethods != '')
        && ($moduleNameToGetMethods != $moduleName)
    ) {
        continue;
    }

    $translation = translate('page_titles.modules.' . $moduleName);

?>
    <h3>
        <?php if ($moduleNameToGetMethods == $moduleName) : ?>
            <?= $translation ?>
        <?php else : ?>
            <a href="/<?= $moduleName ?>"><?= $translation ?></a>
        <?php endif; ?>
    </h3>

    <ul>
        <?php foreach ($methodsList as $methodData) : ?>
            <li>
                <a href="/<?= $moduleName . '/' . $methodData['url'] ?>"><?= $methodData['name'] ?></a>
                <p><?= $methodData['info'] ?></p>
            </li>
        <?php endforeach; ?>
    </ul>

    <?php
        if ($moduleNameToGetMethods == $moduleName) {
            break;
        }
    ?>
<?php endforeach; ?>
