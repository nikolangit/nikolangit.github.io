<?php

/**
 * Namespace.
 */
namespace Modules\Photos\Classes;

/**
 * Required classes.
 */
use Common;

/**
 * Photos handler.
 * 
 * It handles photo methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Photos
{

    public static $fields = [
        'getRecent' => [
            'api_key',
            'extras',
            'per_page',
            'page',
        ],
    ];

    /**
     * It returns available sizes.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return array Available sizes.
     */
    public static function availlableSizes()
    {
        $ret = Common::defaultResponse();

        $ret['data'] = [
            [
                'name' => translate('flickr.sizes.original'),
                'size' => '',
            ],
            [
                'name' => translate('flickr.sizes.square'),
                'size' => '75x75',
            ],
            [
                'name' => translate('flickr.sizes.lg_square'),
                'size' => '150x150',
            ],
            [
                'name' => translate('flickr.sizes.thumbnail'),
                'size' => '100x75',
            ],
            [
                'name' => translate('flickr.sizes.small'),
                'size' => '240x180',
            ],
            [
                'name' => translate('flickr.sizes.small_320'),
                'size' => '320x240',
            ],
            [
                'name' => translate('flickr.sizes.small_400'),
                'size' => '400x300',
            ],
            [
                'name' => translate('flickr.sizes.medium'),
                'size' => '500x375',
            ],
            [
                'name' => translate('flickr.sizes.medium_640'),
                'size' => '640x480',
            ],
            [
                'name' => translate('flickr.sizes.medium_800'),
                'size' => '800x600',
            ],
            [
                'name' => translate('flickr.sizes.large'),
                'size' => '1024x768',
            ],
            [
                'name' => translate('flickr.sizes.large_1600'),
                'size' => '1600x1200',
            ],
            [
                'name' => translate('flickr.sizes.large_2048'),
                'size' => '2048x1536',
            ],
            [
                'name' => translate('flickr.sizes.x_large'),
                'size' => '2816x2112',
            ],
        ];

        $ret['labels'] = translateLabels([
            'name',
            'size',
        ]);

        return $ret;
    }

    /**
     * It returns recent photos data.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  array $params Requested parameters.
     * @return array         Recent photos data.
     */
    public static function getRecent(array $params)
    {
        $ret = Common::defaultResponse();

        $paramsOrder = [
            'extras',
            'per_page',
            'page',
        ];

        // Get Flickr's data.
        $flickrData = Common::getData(
            __METHOD__,
            $params,
            $paramsOrder
        );

        if (isset($flickrData['type'])
            && ($flickrData['type'] != MESSAGE_TYPE_SUCCESS)
        ) {
            return $flickrData;
        }

        // Parse Flickr's data.
        $photos = $flickrData['photos']['photo'];
        foreach ($photos as $photo) {
            $key_name = $params['extras'];

            switch ($key_name) {
                case 'date_upload':
                case 'date_taken':
                case 'owner_name':
                case 'icon_server':
                case 'original_format':
                case 'last_update':
                case 'path_alias':
                    $key_name = str_replace('_', '', $key_name);
                    break;
            }

            $extras = null;
            if (isset($photo[$key_name])) {
                $extras = $photo[$key_name];

                if (isset($extras['_content'])) {
                    $extras = $extras['_content'];
                }

            } else {
                if ($key_name == 'geo') {
                    $extras = [
                        'lat' => $photo['latitude'],
                        'lng' => $photo['longitude'],
                    ];
                }
            }

            $ret['data'][] = [
                'id'              => $photo['id'],
                'is_public'       => $photo['ispublic'],
                'title'           => $photo['title'],
                $params['extras'] => $extras,
            ];
        }

        $ret['labels'] = translateLabels([
            'id',
            'is_public',
            'title',
            $params['extras']
        ]);

        return $ret;
    }

    /**
     * It returns photos size data.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  array $params Requested parameters.
     * @return array         Photos size data.
     */
    public static function getSizes(array $params)
    {
        $ret = Common::defaultResponse();

        $paramsOrder = [
            'photo_id'
        ];

        // Get Flickr's data.
        $flickrData = Common::getData(
            __METHOD__,
            $params,
            $paramsOrder
        );

        if (isset($flickrData['type'])
            && ($flickrData['type'] != MESSAGE_TYPE_SUCCESS)
        ) {
            return $flickrData;
        }

        $translations = [
            'Original'     => translate('flickr.sizes.original'),
            'Square'       => translate('flickr.sizes.square'),
            'Large Square' => translate('flickr.sizes.lg_square'),
            'Thumbnail'    => translate('flickr.sizes.thumbnail'),
            'Small'        => translate('flickr.sizes.small'),
            'Small 320'    => translate('flickr.sizes.small_320'),
            'Small 400'    => translate('flickr.sizes.small_400'),
            'Medium'       => translate('flickr.sizes.medium'),
            'Medium 640'   => translate('flickr.sizes.medium_640'),
            'Medium 800'   => translate('flickr.sizes.medium_800'),
            'Large'        => translate('flickr.sizes.large'),
            'Large 1600'   => translate('flickr.sizes.large_1600'),
            'Large 2048'   => translate('flickr.sizes.large_2048'),
            'X-Large 3K'   => translate('flickr.sizes.x_large'),
        ];

        // Parse Flickr's data.
        $sizes = $flickrData['sizes']['size'];
        foreach ($sizes as $size) {
            $translation = isset($translations[$size['label']])
                ? $translations[$size['label']]
                : $size['label']
            ;

            $ret['data'][] = [
                'img_size_name' => $translation,
                'size'          => $size['width'] . 'x' . $size['height'],
                'ratio'         => number_format($size['width'] / $size['height'], 2) . ':1',
                'img_url'       => $size['source'],
            ];
        }

        $ret['labels'] = translateLabels([
            'img_size_name',
            'img_size',
            'ratio',
            'img',
        ]);

        return $ret;
    }

}
