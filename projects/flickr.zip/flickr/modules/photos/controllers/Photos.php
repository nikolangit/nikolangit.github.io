<?php

/**
 * Namespace.
 */
namespace Modules\Photos\Controllers;

/**
 * Required classes.
 */
use Input;
use Response;
use Validator;
use Modules\Photos\Classes\Photos as ClassPhotos;

/**
 * Photos handler.
 * 
 * It handles photo methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Photos
{

    private $commonFields = [
        'sort' => [
            'faves',
            'views',
            'comments',
            'interesting',
        ],
        'extras' => [
            'description',
            'license',
            'date_upload',
            'date_taken',
            'owner_name',
            'icon_server',
            'original_format',
            'last_update',
            'geo',
            'tags',
            'machine_tags',
            'o_dims',
            'views',
            'media',
            'path_alias',
            'url_sq',
            'url_t',
            'url_s',
            'url_q',
            'url_m',
            'url_n',
            'url_z',
            'url_c',
            'url_l',
            'url_o',
        ],
        'per_page' => [ 1, 20 ],
        'page' => [ 1, 10 ],
    ];

    /**
     * It returns available sizes.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return json
     */
    public function availlableSizes()
    {
        $data = ClassPhotos::availlableSizes();

        return Response::json($data);
    }

    /**
     * It returns recent photos.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return json
     */
    public function getRecent()
    {
        $params = Input::all();

        // Validation rules.
        $rules = [
            'extras'   => 'nullable|in:' . implode(',', $this->commonFields['extras']),
            'per_page' => 'nullable|between:1,20',
            'page'     => 'nullable|between:1,10',
        ];

        $validator = new Validator;

        // Validate parameters.
        $validation = $validator->make(
            $params,
            $rules
        );

        // Validation failed.
        if ($validation->fails()) {
            $data = $validation->error();
        } else {
            $data = ClassPhotos::getRecent($params);
        }

        return Response::json($data);
    }

    /**
     * It returns photo sizes.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return json
     */
    public function getSizes()
    {
        $params = Input::all();

        // Validation rules.
        $rules = [
            'photo_id' => 'required|string',
        ];

        $validator = new Validator;

        // Validate parameters.
        $validation = $validator->make(
            $params,
            $rules
        );

        // Validation failed.
        if ($validation->fails()) {
            $data = $validation->error();
        } else {
            $data = ClassPhotos::getSizes($params);
        }

        return Response::json($data);
    }

}
