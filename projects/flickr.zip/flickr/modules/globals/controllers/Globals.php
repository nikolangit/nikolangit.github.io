<?php

/**
 * Namespace.
 */
namespace Modules\Globals\Controllers;

/**
 * Required classes.
 */
use Input;
use Response;
use Language;

/**
 * Global handler.
 * 
 * It handles global methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Globals
{

    /**
     * It changes language.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return json
     */
    public function changeLang()
    {
        $currentLangTranslation = translate('langs.' . Language::get());

        $data = [
            'type'   => MESSAGE_TYPE_SUCCESS,
            'title'  => translate('success.changed_lang.title'),
            'msg'    => translate('success.changed_lang.msg', [ $currentLangTranslation ]),
            'toastr' => true,
        ];

        $params = Input::get(['lang']);

        if (isset($params)) {
            Language::set($params['lang']);
        }

        return Response::json($data);
    }

}
