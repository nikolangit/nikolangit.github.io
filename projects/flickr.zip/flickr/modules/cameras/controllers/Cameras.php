<?php

/**
 * Namespace.
 */
namespace Modules\Cameras\Controllers;

/**
 * Required classes.
 */
use Input;
use Response;
use Validator;
use Modules\Cameras\Classes\Cameras as ClassCameras;

/**
 * Camera handler.
 * 
 * It handles camera methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Cameras
{

    /**
     * It returns brands data.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return json
     */
    public function getBrands()
    {
        $params = Input::all();

        // Validation rules.
        $rules = [
            'order_by_name' => 'nullable|str|in:id,name',
            'order_by_dir'  => 'nullable|str|in:asc,desc',
        ];

        $validator = new Validator;

        // Validate parameters.
        $validation = $validator->make(
            $params,
            $rules
        );

        // Validation failed.
        if ($validation->fails()) {
            $data = $validation->error();
        } else {
            $data = ClassCameras::getBrands($params);
        }

        return Response::json($data);
    }

    /**
     * It returns brand models data.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return json
     */
    public function getBrandModels()
    {
        $params = Input::all();

        // Validation rules.
        $rules = [
            'brand' => 'required|str',
        ];

        $validator = new Validator;

        // Validate parameters.
        $validation = $validator->make(
            $params,
            $rules
        );

        // Validation failed.
        if ($validation->fails()) {
            $data = $validation->error();
        } else {
            $data = ClassCameras::getBrandModels($params);
        }

        return Response::json($data);
    }

}
