<?php

/**
 * Namespace.
 */
namespace Modules\Cameras\Classes;

/**
 * Required classes.
 */
use Common;

/**
 * Camera handler.
 * 
 * It handles camera methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Cameras
{

    public static $fields = [
        'getBrands' => [
            'extras',
            'per_page',
            'page',
        ],
        'getBrandModels' => [
            'brand',
        ],
    ];

    /**
     * It returns brands data.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  array $params Requested parameters.
     * @return array         Brands data.
     */
    public static function getBrands(array $params)
    {
        $ret = Common::defaultResponse();

        $paramsOrder = [
            'extras',
            'per_page',
            'page',
        ];

        // Get Flickr's data.
        $flickrData = Common::getData(
            __METHOD__,
            $params,
            $paramsOrder
        );

        if (isset($flickrData['type'])
            && ($flickrData['type'] != MESSAGE_TYPE_SUCCESS)
        ) {
            return $flickrData;
        }

        // Parse Flickr's data.
        $brands = $flickrData['brands']['brand'];
        foreach ($brands as $brand) {
            $ret['data'][] = [
                'id'   => $brand['id'],
                'name' => $brand['name'],
            ];
        }

        $orderByField = 'id';
        if (isset($params['order_by_name'])) {
            $orderByField = $params['order_by_name'];
        }

        $orderByDirection = SORT_ASC;
        if (isset($params['order_by_dir'])) {
            $orderByDirection = $params['order_by_dir'] == 'asc'
                ? SORT_ASC
                : SORT_DESC
            ;
        }

        // Sort data.
        sortMultidimensionalArrayByKeyName(
            $ret['data'],
            $orderByField,
            $orderByDirection
        );

        $ret['labels'] = translateLabels([
            'id',
            'name',
        ]);

        return $ret;
    }

    /**
     * It returns brands model data.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  array $params Requested parameters.
     * @return array         Brands model data.
     */
    public static function getBrandModels(array $params)
    {
        $ret = Common::defaultResponse();

        $paramsOrder = [
            'brand',
        ];

        // Get Flickr's data.
        $flickrData = Common::getData(
            __METHOD__,
            $params,
            $paramsOrder
        );

        if (isset($flickrData['type'])
            && ($flickrData['type'] != MESSAGE_TYPE_SUCCESS)
        ) {
            return $flickrData;
        }

        // Parse Flickr's data.
        $cameras = $flickrData['cameras']['camera'];
        foreach ($cameras as $camera) {
            $imgSm = isset($camera['images']['small']['_content'])
                ? $camera['images']['small']['_content']
                : '/imgs/no-image.jpg'
            ;

            $imgLg = isset($camera['images']['large']['_content'])
                ? $camera['images']['large']['_content']
                : '/imgs/no-image.jpg'
            ;

            $ret['data'][] = [
                'id'     => $camera['id'],
                'name'   => $camera['name']['_content'],
                'images' => [
                    'sm' => $imgSm,
                    'lg' => $imgLg,
                ],
            ];
        }

        $ret['labels'] = translateLabels([
            'id',
            'name',
            'img_sm',
            'img_lg',
        ]);

        return $ret;
    }

}
