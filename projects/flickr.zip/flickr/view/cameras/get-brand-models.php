<div class="row">
    <div class="col-md-12">
        <h1><?= $pageData['title'] ?></h1>

        <p><?= $pageData['desc'] ?></p>
    </div>

    <div class="col-md-12 my-3">
        <div class="form-group">
            <label><?= translate('flickr.labels.brand') ?></label>
            <input id="brand" class="form-control form-items" autofocus/>
        </div>

        <button type="button" id="get-data" class="btn btn-primary mt-3"><?= translate('flickr.labels.get_data') ?></button>
    </div>

    <div class="col-md-12 my-3">
        <p><?= translate('flickr.labels.total_rows') ?>: <strong id="total-rows">0</strong>.</p>
        <div id="render-holder" class="table-responsive"></div>
    </div>
</div>
