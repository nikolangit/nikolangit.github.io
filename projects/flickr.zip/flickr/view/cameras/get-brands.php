<div class="row">
    <div class="col-md-12">
        <h1><?= $pageData['title'] ?></h1>

        <p><?= $pageData['desc'] ?></p>
    </div>

    <div class="col-md-12 my-3">
        <div class="form-group">
            <label><?= translate('flickr.labels.order_by_name') ?></label>
            <select id="order_by_name" class="form-select form-items">
                <option value="id" selected><?= translate('flickr.labels.id') ?></option>
                <option value="name"><?= translate('flickr.labels.name') ?></option>
            </select>
        </div>

        <div class="form-group">
            <label><?= translate('flickr.labels.order_by_dir') ?></label>
            <select id="order_by_dir" class="form-select form-items">
                <option value="asc" selected><?= translate('flickr.labels.asc') ?></option>
                <option value="desc"><?= translate('flickr.labels.desc') ?></option>
            </select>
        </div>

        <button type="button" id="get-data" class="btn btn-primary mt-3"><?= translate('flickr.labels.get_data') ?></button>
    </div>

    <div class="col-md-12 my-3">
        <p><?= translate('flickr.labels.total_rows') ?>: <strong id="total-rows">0</strong>.</p>
        <div id="render-holder" class="table-responsive"></div>
    </div>
</div>
