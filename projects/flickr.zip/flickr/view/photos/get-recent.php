<div class="row">
    <div class="col-md-12">
        <h1><?= $pageData['title'] ?></h1>

        <p><?= $pageData['desc'] ?></p>
    </div>

    <div class="col-md-12 my-3">
        <div class="form-group">
            <label><?= translate('flickr.labels.extras') ?></label>
            <select id="extras" class="form-select form-items" autofocus><?php
                $arr = [
                    'owner_name',
                    'media',
                    'original_format',
                    'geo',
                    'tags',
                    'machine_tags',
                    'description',
                    'license',
                    'date_upload',
                    'date_taken',
                    'last_update',
                    'views',
                    'path_alias',
                    'url_sq',
                    'url_t',
                    'url_s',
                    'url_n',
                    'url_m',
                    'url_z',
                    'url_c',
                    'url_q',
                    'url_l',
                    'url_o',
                    'icon_server',
                    'o_dims',
                ];

                foreach ($arr as $index => $item) {
                    echo '<option value="' . $item . '">' . translate('flickr.labels.' . $item) . '</option>';
                }
            ?></select>
        </div>

        <div class="form-group">
            <label><?= translate('flickr.labels.per_page') ?></label>
            <input type="number" id="per_page" class="form-control form-items" min="1" max="20" value="1">
        </div>

        <div class="form-group">
            <label><?= translate('flickr.labels.page') ?></label>
            <input type="number" id="page" class="form-control form-items" min="1" max="10" value="1">
        </div>

        <button type="button" id="get-data" class="btn btn-primary mt-3"><?= translate('flickr.labels.get_data') ?></button>
    </div>

    <div class="col-md-12 my-3">
        <p><?= translate('flickr.labels.total_rows') ?>: <strong id="total-rows">0</strong>.</p>
        <div id="render-holder" class="table-responsive"></div>
    </div>
</div>
