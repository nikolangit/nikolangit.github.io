<div class="row">
    <div class="col-md-12 text-center">
        <div class="error-page-holder">
            <h1 class="text-danger">404</h1>
            <p><?= translate('page_titles.404') ?></p>
        </div>
    </div>
</div>
