<?php

spl_autoload_register(function ($class_name) {
    $path_arr = explode(DIRECTORY_SEPARATOR, $class_name);

    $class_name = array_pop($path_arr) . '.php';
    $namespace  = strtolower(implode(DIRECTORY_SEPARATOR, $path_arr));

    if (empty($namespace)) {
        $namespace = 'src' . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR;
    } else {
        $namespace .= DIRECTORY_SEPARATOR;
    }

    $path = __DIR__ . DIRECTORY_SEPARATOR . $namespace . $class_name;

    if (file_exists($path)) {
        include_once $path;
    }
});

require_once 'src/config/config.php';
require_once 'src/config/functions.php';
require_once 'src/routes.php';
