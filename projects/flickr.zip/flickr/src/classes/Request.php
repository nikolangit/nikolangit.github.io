<?php

/**
 * Request handler.
 * 
 * It handles request methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Request
{

    /**
     * It returns the requested HTTP method.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return string
     */
    public static function method()
    {
        return $_SERVER['REQUEST_METHOD'];
    }

    /**
     * It returns requested URI.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return string
     */
    public static function uri()
    {
        return isset($_GET['uri'])
            ? $_GET['uri']
            : ''
        ;
    }

    /**
     * It returns the content type of a request.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return string
     */
    public static function contentType($typeToCheck = '')
    {
        return (bool)strpos($_SERVER['CONTENT_TYPE'], $typeToCheck);
    }

    /**
     * It sets header value.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return string
     */
    public static function set($key = '', $value = '')
    {
        header($key . ': ' . $value);
    }

}
