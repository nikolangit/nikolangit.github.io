<?php

/**
 * Input handler.
 * 
 * It handles input methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Input
{

    /**
     * It returns all requested payload.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return array Requested payload.
     */
    public static function all()
    {
        $data = file_get_contents('php://input');

        if (Request::contentType('json')) {
            $data = json_decode($data, true);
        }

        return $data;
    }

    /**
     * It gets the certain value from requests payload.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return array
     */
    public static function get($fields = [])
    {
        $ret = [];

        $data = file_get_contents('php://input');

        // Check request content type.
        if (Request::contentType('json')) {
            $data = json_decode($data, true);
        }

        foreach ($fields as $field) {
            if (array_key_exists($field, $data)) {
                $ret[$field] = $data[$field];
            }
        }

        return $ret;
    }

}
