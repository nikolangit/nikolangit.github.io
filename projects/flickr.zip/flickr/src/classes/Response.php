<?php

/**
 * Response handler.
 * 
 * It handles response methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Response
{

    /**
     * It returns the data as JSON.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  array $data   Data to be encoded.
     * @param  int   $option JSON options.
     * @return json          JSON data.
     */
    public static function json(array $data, int $option = JSON_UNESCAPED_UNICODE)
    {
        if (!is_array($data) && !is_object($data)) {
            $data = [
                'type'  => MESSAGE_TYPE_ERROR,
                'title' => translate('errors.invalid_json.title'),
                'msg'   => translate('errors.invalid_json.msg'),
            ];
        }

        if (!isset($data['toastr'])) {
            if (isset($data['type'])  &&  ($data['type'] != MESSAGE_TYPE_SUCCESS)) {
                $data['toastr'] = true;
            }
        }

        header('Content-Type: application/json');
        die(json_encode($data, $option));
    }

}
