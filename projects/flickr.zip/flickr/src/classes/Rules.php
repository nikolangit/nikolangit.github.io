<?php

/**
 * Rules handler.
 * 
 * It handles rules methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Rules
{

    private $params;
    private $keyName;
    private $paramValue;
    private $nullable = false;

    public $ruleValue;
    public $status = false;

    public function __construct(
        $params = [],
        $keyName = ''
    ) {
        if (!array_key_exists($keyName, $params)) {
            $this->status      = VALIDATION_STATUS_MISSING_KEY;
            $this->paramValue = [];

        } else {
            $this->paramValue = $params[$keyName];
        }

        $this->params  = $params;
        $this->keyName = $keyName;

        return $this;
    }

    /**
     * It checks if the value is required.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return boolean Validation status.
     */
    public function required()
    {
        return array_key_exists($this->keyName, $this->params)
            ? VALIDATION_STATUS_SUCCESS
            : VALIDATION_STATUS_ERROR
        ;
    }

    /**
     * It checks if the value is nullable.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return boolean Validation status.
     */
    public function nullable()
    {
        $this->nullable = array_key_exists(
            $this->keyName,
            $this->params
        );

        return VALIDATION_STATUS_SUCCESS;
    }

    /**
     * It checks if the value exists inside multiple options.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return boolean Validation status.
     */
    public function in()
    {
        if (!$this->nullable) {
            return VALIDATION_STATUS_SUCCESS;
        }

        if (is_array($this->paramValue)) {
            $diff = array_diff($this->ruleValue, $this->paramValue);

            return count($diff)
                ? VALIDATION_STATUS_ERROR
                : VALIDATION_STATUS_SUCCESS
            ;
        }

        return in_array($this->paramValue, $this->params)
            ? VALIDATION_STATUS_SUCCESS
            : VALIDATION_STATUS_ERROR
        ;
    }

    /**
     * It checks if the value is bigger or equal then given.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return boolean Validation status.
     */
    public function min()
    {
        if (!$this->nullable) {
            return VALIDATION_STATUS_SUCCESS;
        }

        if (is_null($this->paramValue)
            || is_bool($this->paramValue)
            || is_object($this->paramValue)
        ) {
            return VALIDATION_STATUS_INVALID_TYPE;
        }

        if (is_string($this->paramValue)) {
            $this->paramValue = strlen($this->paramValue);
        }

        if (is_array($this->paramValue)) {
            $this->paramValue = count($this->paramValue);
        }

        return $this->paramValue >= $this->ruleValue
            ? VALIDATION_STATUS_SUCCESS
            : VALIDATION_STATUS_ERROR
        ;
    }

    /**
     * It checks if the value is smaller or equal then given.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return boolean Validation status.
     */
    public function max()
    {
        if (!$this->nullable) {
            return VALIDATION_STATUS_SUCCESS;
        }

        if (is_null($this->paramValue)
            || is_bool($this->paramValue)
            || is_object($this->paramValue)
        ) {
            return VALIDATION_STATUS_INVALID_TYPE;
        }

        if (is_string($this->paramValue)) {
            $this->paramValue = strlen($this->paramValue);
        }

        if (is_array($this->paramValue)) {
            $this->paramValue = count($this->paramValue);
        }

        return $this->paramValue <= $this->ruleValue
            ? VALIDATION_STATUS_SUCCESS
            : VALIDATION_STATUS_ERROR
        ;
    }

    /**
     * It checks if the value is between.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return boolean Validation status.
     */
    public function between()
    {
        if (!$this->nullable) {
            return VALIDATION_STATUS_SUCCESS;
        }

        if (is_null($this->paramValue)
            || is_bool($this->paramValue)
            || is_object($this->paramValue)
        ) {
            return VALIDATION_STATUS_INVALID_TYPE;
        }

        if (is_string($this->paramValue)) {
            $this->paramValue = strlen($this->paramValue);
        }

        if (is_array($this->paramValue)) {
            $this->paramValue = count($this->paramValue);
        }

        $ruleValue = array_map(function ($item) {
            return (float)$item;
        }, $this->ruleValue);

        return ($this->paramValue >= $ruleValue[0])  &&  ($this->paramValue <= $ruleValue[1])
            ? VALIDATION_STATUS_SUCCESS
            : VALIDATION_STATUS_ERROR
        ;
    }

    /**
     * It checks if the value is match given regular expression.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return boolean Validation status.
     */
    public function regex()
    {
        if (!$this->nullable) {
            return VALIDATION_STATUS_SUCCESS;
        }

        if (!is_string($this->paramValue)) {
            return VALIDATION_STATUS_INVALID_TYPE;
        }

        return (bool)preg_match($this->ruleValue, $this->paramValue)
            ? VALIDATION_STATUS_SUCCESS
            : VALIDATION_STATUS_ERROR
        ;
    }

    /**
     * It checks if the value doesn't matches given regular expression.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return boolean Validation status.
     */
    public function not_regex()
    {
        if (!$this->nullable) {
            return VALIDATION_STATUS_SUCCESS;
        }

        if (!is_string($this->paramValue)) {
            return VALIDATION_STATUS_INVALID_TYPE;
        }

        return (bool)preg_match($this->ruleValue, $this->paramValue)
            ? VALIDATION_STATUS_ERROR
            : VALIDATION_STATUS_SUCCESS
        ;
    }

    /**
     * It checks if the data type of value.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return boolean Validation status.
     */
    public function type()
    {
        if (!$this->nullable) {
            return VALIDATION_STATUS_SUCCESS;
        }

        switch ($this->ruleValue) {
            case 'null':
                return is_null($this->paramValue)
                    ? VALIDATION_STATUS_SUCCESS
                    : VALIDATION_STATUS_ERROR
                ;

            case 'bool':
                return is_bool($this->paramValue)
                    ? VALIDATION_STATUS_SUCCESS
                    : VALIDATION_STATUS_ERROR
                ;

            case 'int':
            case 'integer':
                return is_integer($this->paramValue)
                    ? VALIDATION_STATUS_SUCCESS
                    : VALIDATION_STATUS_ERROR
                ;

            case 'float':
                return is_float($this->paramValue)
                    ? VALIDATION_STATUS_SUCCESS
                    : VALIDATION_STATUS_ERROR
                ;

            case 'dbl':
            case 'double':
                return is_double($this->paramValue)
                    ? VALIDATION_STATUS_SUCCESS
                    : VALIDATION_STATUS_ERROR
                ;

            case 'num':
            case 'numeric':
                return is_numeric($this->paramValue)
                    ? VALIDATION_STATUS_SUCCESS
                    : VALIDATION_STATUS_ERROR
                ;

            case 'str':
            case 'string':
                return is_string($this->paramValue)
                    ? VALIDATION_STATUS_SUCCESS
                    : VALIDATION_STATUS_ERROR
                ;

            case 'arr':
            case 'array':
                return is_array($this->paramValue)
                    ? VALIDATION_STATUS_SUCCESS
                    : VALIDATION_STATUS_ERROR
                ;

            case 'obj':
            case 'object':
                return is_object($this->paramValue)
                    ? VALIDATION_STATUS_SUCCESS
                    : VALIDATION_STATUS_ERROR
                ;

            default:
                break;
        }

        return VALIDATION_STATUS_INVALID_TYPE;
     }

}
