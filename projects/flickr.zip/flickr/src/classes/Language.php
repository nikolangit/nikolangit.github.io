<?php

/**
 * Language handler.
 * 
 * It handles language methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Language
{

    /**
     * It returns the language names or language codes.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  boolean $useTranslations Wheater to get language name or just code.
     * @return array                    Language names or codes.
     */
    public static function list($useTranslations = false)
    {
        $ret = [];

        $langs = [
            'en',
            'sr-latn',
            'sr-cyrl',
        ];

        foreach ($langs as $lang) {
            if ($useTranslations) {
                $ret[$lang] = translate('langs.' . $lang);
            } else {
                $ret[] = $lang;
            }
        }

        return $ret;
    }

    /**
     * It checks if the language code exists.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  string  $langCode Language code.
     * @return boolean
     */
    public static function check($langCode = '')
    {
        return in_array($langCode, self::list());
    }

    /**
     * It gets the current language code.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return string Language code.
     */
    public static function get()
    {
        $ret = file_get_contents('lang.txt');
        if (!self::check($ret)) {
            $ret = DEFAULT_LANG;
        }

        return $ret;
    }

    /**
     * It sets the language code.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  string $langCode Language code to set.
     * @return string           Language code.
     */
    public static function set($langCode = '')
    {
        if (!self::check($langCode)) {
            $langCode = DEFAULT_LANG;
        }

        Request::set('Lang', $langCode);
        file_put_contents('lang.txt', $langCode);

        return $langCode;
    }

}
