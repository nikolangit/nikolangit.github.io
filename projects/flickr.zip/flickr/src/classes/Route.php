<?php

/**
 * Route handler.
 * 
 * It handles route methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Route
{

    private static $isView       = false;
    private static $isMethodApi = false;

    /**
     * It executes the class method or loads template.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  string $path 
     * @return void
     */
    public static function execute($path = '')
    {
        if (self::$isView) {
            require_once 'templates/index.php';
            return;
        }

        $tmpArr = explode('/', $path);
        if (self::$isMethodApi) {

            $controllerPath   = $tmpArr[0];
            $controllerMethod = $tmpArr[1];

            if (class_exists($controllerPath)) {
                $controller = new $controllerPath();
                return $controller->{$controllerMethod}();
            }
        }

        return;
    }

    /**
     * It checks the route.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  array $routeData Route data.
     * @return void
     */
    public static function match($routeData = [])
    {
        self::$isView = !preg_match('/^' . str_replace('/', '\\/', PROJECT_API_URL) . '/', Request::uri());

        if (($routeData[0] == Request::method())  &&  (PROJECT_API_URL . $routeData[1] == Request::uri())) {
            self::$isMethodApi = true;
            return self::execute($routeData[2]);
        } else {
            return self::execute(Request::uri());
        }
    }

}
