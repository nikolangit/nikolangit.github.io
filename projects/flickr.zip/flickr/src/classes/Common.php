<?php

/**
 * Common handler.
 * 
 * It handles common methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Common
{

    /**
     * It return all active methods meta data.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  string $module Module name.
     * @return void
     */
    public static function getActiveMethods($module = '')
    {
        $ret = [];

        $classFileNames = [
            'cameras' => [
                'Modules\Cameras\Classes\Cameras',
            ],
            'photos' => [
                'Modules\Photos\Classes\Photos',
            ],
        ];

        foreach ($classFileNames as $moduleName => $namespaces) {
            $ret[$moduleName] = [];

            foreach ($namespaces as $namespace) {
                // Get method names from class.
                $classMethods = get_class_methods($namespace);

                foreach ($classMethods as $classMethod) {
                    $ret[$moduleName][] = [
                        'name' => $classMethod,
                        'info' => translate('flickr.method_info.' . $moduleName . '.' . $classMethod . 'Info'),
                        'url'  => fromCamelToKebabCase($classMethod),
                    ];
                }
            }

            if ($moduleName == $module) {
                break;
            }
        }

        return $ret;
    }

    /**
     * It returns default response.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  string $responseType Response type.
     * @param  array  $values       Translation values.
     * @return array                Default response.
     */
    public static function defaultResponse(string $responseType = '', $values = [])
    {
        $ret = [];

        switch ($responseType) {
            case 'validation-type-' . VALIDATION_STATUS_ERROR:
                $ret = [
                    'type'   => MESSAGE_TYPE_ERROR,
                    'title'  => translate('errors.validation.title'),
                    'msg'    => translate('errors.validation.msg', $values),
                    'toastr' => true,
                ];
                break;

            case 'validation-type-' . VALIDATION_STATUS_MISSING_KEY:
                $ret = [
                    'type'   => MESSAGE_TYPE_WARNING,
                    'title'  => translate('warnings.validation.missing_key.title'),
                    'msg'    => translate('warnings.validation.missing_key.msg', $values),
                    'toastr' => true,
                ];
                break;

            case 'validation-type-' . VALIDATION_STATUS_INVALID_TYPE:
                $ret = [
                    'type'   => MESSAGE_TYPE_WARNING,
                    'title'  => translate('warnings.validation.invalid_key_type.title'),
                    'msg'    => translate('warnings.validation.invalid_key_type.msg', $values),
                    'toastr' => true,
                ];
                break;

            case 'api-not-found':
                $ret = [
                    'type'   => MESSAGE_TYPE_WARNING,
                    'title'  => translate('warnings.requested_api_url_not_found.title'),
                    'msg'    => translate('warnings.requested_api_url_not_found.msg'),
                    'toastr' => true,
                ];
                break;

            default:
                $ret = [
                    'type'  => MESSAGE_TYPE_SUCCESS,
                    'title' => '',
                    'msg'   => '',
                ];
                break;
        }

        return $ret;
    }

    /**
     * It prepares URL for Flickr's site.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  string $fullMethodName Method's full name.
     * @param  array  $params         Requested parameters for Flickr.
     * @param  array  $paramsOrder    Order of requested parameters.
     * @return string                 URL for Flickr.
     */
    private static function prepareUrl($fullMethodName = '', $params = [], $paramsOrder = [])
    {
        $mainParams = [
            'method'  => 'flickr' . parseFlickrMethodName($fullMethodName),
            'api_key' => FLICKR_API_KEY,
        ];

        if (isset($params['api_key'])) {
            $mainParams['api_key'] = $params['api_key'];
        }

        if (empty($paramsOrder)) {
            $paramsOrder = array_keys($params);
        }

        // Set order of parameters.
        foreach ($paramsOrder as $fieldName) {
            if (!isset($params[$fieldName])) {
                continue;
            }

            if (is_array($params[$fieldName])) {
                $params[$fieldName] = implode(',', $params[$fieldName]);
            }

            $mainParams[$fieldName] = $params[$fieldName];
        }

        $mainParams['format']         = 'json';
        $mainParams['nojsoncallback'] = '1';

        $encodedParams = [];
        foreach ($mainParams as $key => $value) {
            $encodedParams[] = $key . '=' . $value;
        }

        return FLICKR_API_URL . implode('&', $encodedParams);
    }

    /**
     * It returns data from the Flickr.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  string $fullMethodName Method's full name.
     * @param  array  $params         Requested parameters for Flickr.
     * @param  array  $paramsOrder    Order of requested parameters.
     * @return array                  Flickr's API response data.
     */
    public static function getData($fullMethodName = '', $params = [], $paramsOrder = [])
    {
        $ret = self::defaultResponse();

        $url = self::prepareUrl($fullMethodName, $params, $paramsOrder);

        $responseData = json_decode(file_get_contents($url), true);
        if (empty($responseData)) {
            $ret = self::defaultResponse('api-not-found');

        } else if ($responseData['stat'] == 'fail') {
        	$ret = [
        		'type'   => MESSAGE_TYPE_ERROR,
                'title'  => translate('flickr.errors.code_status.' . $responseData['code'] . '.title'),
                'msg'    => translate('flickr.errors.code_status.' . $responseData['code'] . '.msg'),
                'toastr' => true,
        	];

        } else {
            $ret = $responseData;
        }

        return $ret;
    }

}
