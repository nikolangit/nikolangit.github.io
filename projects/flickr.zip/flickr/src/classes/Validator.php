<?php

/**
 * Validator handler.
 * 
 * It handles validator methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class Validator
{

    private $allowedTypes = [
        'null',
        'bool',
        'int',
        'integer',
        'float',
        'dbl',
        'double',
        'num',
        'numeric',
        'str',
        'string',
        'arr',
        'array',
        'obj',
        'object',
    ];

    private $fails = false;
    private $error = [];

    /**
     * It creates rules on parameters.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  array  $params Request parameters.
     * @param  array  $rules  Rules for parameters.
     * @return object
     */
    public function make(
        $params = [],
        $rules = []
    ) {
        foreach ($rules as $fieldName => $rule) {
            $rulesClass = new Rules(
                $params,
                $fieldName
            );

            $rulesToTest = $this->getRuleTypeAndValue($rule);
            foreach ($rulesToTest as $methodName => $testRule) {
                if (method_exists($rulesClass, $methodName)) {
                    $rulesClass->ruleValue = $testRule;

                    $status = $rulesClass->$methodName();

                    if ($status != VALIDATION_STATUS_SUCCESS) {
                        $this->fails = true;
                        $this->error = Common::defaultResponse(
                            'validation-type-' . $status,
                            [
                                translate('flickr.labels.' . $fieldName)
                            ]
                        );
                        break;
                    }
                }
            }

            if ($this->fails) {
                break;
            }
        }

        return $this;
    }

    /**
     * It returns the status of validations.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return boolean
     */
    public function fails()
    {
        return $this->fails;
    }

    /**
     * It returns the errors data.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @return array
     */
    public function error()
    {
        return $this->error;
    }

    /**
     * It splits string validator rule.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  string $rule   Rule for testing the value.
     * @param  string $symbol Symbol to split multiple rules.
     * @return array          Splited rules.
     */
    private function splitValidatorRule($rule = '', $symbol = '|') {
        $ret = [];

        $temp_str = '';
        $counter  = 0;

        while (isset($rule[$counter])) {
            // Check if the rule needs to be splited.
            if ($rule[$counter] == $symbol) {
                if ($counter  &&  ($rule[$counter - 1] == '\\')) {
                    $temp_str[strlen($temp_str) - 1] = $symbol;

                } else {
                    $ret[] = $temp_str;
                    $temp_str = '';
                }

                $counter++;
                continue;
            }

            $temp_str .= $rule[$counter];

            $counter++;
        }

        $ret[] = $temp_str;

        return $ret;
    }

    /**
     * It parses type and value of rule.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  string $rule Rule type and value.
     * @return array        Parsed rule.
     */
    private function getRuleTypeAndValue($rule = '')
    {
        $ret = [];

        $splitRules = $this->splitValidatorRule($rule, '|');
        foreach ($splitRules as $item) {
            // Get type and value of rule.
            preg_match('/^(\w+):?(.*)/', $item, $matches);

            if (!empty($matches)) {
                $methodName = $matches[1];
                $value       = $this->splitValidatorRule($matches[2], ',');

                if ($value[0] == '') {
                    if (in_array($methodName, $this->allowedTypes)) {
                        $value       = $methodName;
                        $methodName = 'type';
                    }
                }

                $ret[$methodName] = $value;
            }
        }

        return $ret;
    }

}
