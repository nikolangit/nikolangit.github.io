<?php

/**
 * View handler.
 * 
 * It handles view methods and functions.
 *
 * @copyright Copyright (©) 2022 (https://nikolangit.github.io)
 * @author    Nikola Nikolić <rogers94kv@gmail.com>
 * @link      https://nikolangit.github.io
 */
class View
{

    /**
     * It returns user defined constants.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  boolean $render Render constants for JavaScript.
     * @return mixed
     */
    public static function appConstants($render = false)
    {
        $ret = [];

        $getDefinedConstants = get_defined_constants(true);
        $userConstants       = $getDefinedConstants['user'];

        foreach ($userConstants as $name => $value) {
            if (preg_match('/^(PROJECT|DEFAULT|MESSAGE|FIELD)/', $name)) {
                if ($render) {
                    $value = is_string($value)
                        ? '\'' . $value . '\''
                        : $value
                    ;

                    $ret[] = $name . ' = ' . $value;

                } else {
                    $ret[$name] = $value;
                }
            }
        }

        return $render
            ? 'const ' . implode(',', $ret) . ';'
            : $ret
        ;
    }

    /**
     * It returns data when displaying the page.
     *
     * @author Nikola Nikolić <rogers94kv@gmail.com>
     * @param  string $pageName
     * @return array
     */
    public static function loadPage(string $pageName = '')
    {
        $ret = [
            'path'    => 'index.php',
            'title'   => translate('page_titles.home'),
            'desc'    => translate('page_titles.home'),
            'js_path' => null,
        ];

        $pageName = preg_replace('/\/+$/', '', $pageName);

        $lang = Language::get();

        switch ($pageName) {
            case '':
            case 'home':
                break;

            // modules
            case 'cameras':
            case 'photos':
                $ret = [
                    'path'  => $pageName . '/index.php',
                    'title' => translate('page_titles.modules.' . $pageName),
                    'desc'  => translate('page_titles.modules.' . $pageName),
                ];
                break;

            // methods
            case 'cameras/get-brands':
            case 'cameras/get-brand-models':
            case 'photos/availlable-sizes':
            case 'photos/get-recent':
            case 'photos/get-sizes':
                $translationKey = preg_replace(
                    [
                        '/\//',
                        '/-/',
                    ],
                    [
                        '.',
                        '_',
                    ],
                    $pageName
                );

                $arr = explode('/', $pageName);

                $methodName = fromKebabToCamelCase($arr[1]);

                $ret = [
                    'path'  => $pageName . '.php',
                    'title' => translate('page_titles.methods.' . $translationKey),
                    'desc'  => translate('flickr.method_info.' . $arr[0] . '.' . $methodName . 'Info'),
                ];
                break;

            case '404':
                $ret = [
                    'path'  => '404.php',
                    'title' => translate('page_titles.404'),
                    'desc'  => translate('page_titles.404'),
                ];
                break;

            default:
                $ret = [
                    'path'  => '404.php',
                    'error' => true,
                    'title' => translate('page_titles.404'),
                    'desc'  => translate('page_titles.404'),
                ];
                break;
        }

        $ret['path'] = 'view/' . $ret['path'];
        $ret['lang'] = $lang;

        return $ret;
    }

}
