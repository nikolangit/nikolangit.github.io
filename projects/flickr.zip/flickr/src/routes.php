<?php

require_once 'routes/cameras.php';
require_once 'routes/photos.php';

Route::match([
    'PUT',
    'testing',
    'Modules\Testing\Controllers\Testing/test'
]);

Route::match([
    'PUT',
    'change/lang',
    'Modules\Globals\Controllers\Globals/changeLang'
]);
