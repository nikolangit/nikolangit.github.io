<?php

Route::match([
    'PUT',
    'cameras/brands/get/info',
    'Modules\Cameras\Controllers\Cameras/getBrandsInfo'
]);

Route::match([
    'PUT',
    'cameras/brands/list',
    'Modules\Cameras\Controllers\Cameras/getBrands'
]);

Route::match([
    'PUT',
    'cameras/brands/models/info',
    'Modules\Cameras\Controllers\Cameras/getBrandModelsInfo'
]);

Route::match([
    'PUT',
    'cameras/brands/models/list',
    'Modules\Cameras\Controllers\Cameras/getBrandModels'
]);
