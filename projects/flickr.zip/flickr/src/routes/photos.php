<?php

Route::match([
    'GET',
    'photos/available-sizes/list',
    'Modules\Photos\Controllers\Photos/availlableSizes'
]);

Route::match([
    'PUT',
    'photos/recent/list',
    'Modules\Photos\Controllers\Photos/getRecent'
]);

Route::match([
    'PUT',
    'photos/sizes/list',
    'Modules\Photos\Controllers\Photos/getSizes'
]);
