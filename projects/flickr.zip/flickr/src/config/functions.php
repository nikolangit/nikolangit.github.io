<?php

/**
 * It returns translation.
 *
 * @author Nikola Nikolić <rogers94kv@gmail.com>
 * @param  string $key    Key value.
 * @param  array  $values Additional values.
 * @return string         Translation.
 */
function translate(string $key, array $values = []) {
    $ret = '';

    // Get language code.
    $langCode = Language::get();

    // Set file path and check if the file exists.
    $filePath = 'translations/' . $langCode . '/lang.php';
    if (!file_exists($filePath)) {
        return $ret;
    }

    // Get translations.
    $getTranslations = include $filePath;

    // Get translation.
    $translation = checkKeysInArrayFromString(
        $getTranslations,
        $key
    );

    // Check if translation string consits values that should be represented as code.
    if (is_string($translation)) {
        $ret = preg_replace('/\`([a-zA-Z0-9_ ]+)\`/', '<code>$1</code>', $translation);
        $ret = nl2br($ret);
    }

    // Check if there are additional translation values that need to be converted to code.
    $hasValues = !empty($values);
    if ($hasValues) {
        foreach ($values as &$value) {
            $value = preg_replace('/\`([a-zA-Z0-9_ ]+)\`/', '<code>$1</code>', $value);
            $value = nl2br($value);
        }
    }

    return $hasValues
        ? vsprintf($ret, $values)
        : $ret
    ;
}

/**
 * It returns translation value.
 *
 * @author Nikola Nikolić <rogers94kv@gmail.com>
 * @param  array  $arr Translation array.
 * @param  string $str Translation path.
 * @return string      Translated key's value.
 */
function checkKeysInArrayFromString(array $arr = [], string $str = '') {
    $getKeys = explode('.', $str);

    foreach ($getKeys as $key) {
        if (isset($arr[$key])) {
            $arr = $arr[$key];
        }
    }

    return $arr;
}

/**
 * It returns multiple translated labels.
 *
 * @author Nikola Nikolić <rogers94kv@gmail.com>
 * @param  array $fields Keys to be translated.
 * @return array         Translated key's value.
 */
function translateLabels(array $fields = []) {
    $ret = [];

    foreach ($fields as $field) {
        $ret[$field] = translate('flickr.labels.' . $field);
    }

    return $ret;
}

/**
 * It parses method name
 *
 * @author Nikola Nikolić <rogers94kv@gmail.com>
 * @param  string $methodConstantValue PHP's constant "__METHOD__" value.
 * @return string                      Parsed method name.
 */
function parseFlickrMethodName(string $methodConstantValue) {
    $ret = '';

    $tmpArr = explode('\\', $methodConstantValue);
    $classAndMethodName = explode('::', $tmpArr[count($tmpArr) - 1]);

    $className  = $classAndMethodName[0];
    $methodName = $classAndMethodName[1];

    $ret = strtolower(preg_replace('/([A-Z])/', '.$1', $className)) . '.' . $methodName;

    return $ret;
}

/**
 * It converts field value to the defined data type.
 *
 * @author Nikola Nikolić <rogers94kv@gmail.com>
 * @param  array $fields Fields to be converted.
 * @return mixed         Converted value.
 */
function formatFields(array $fields = []) {
    $ret = [];

    $fields_data = [
        // field_name => [ data_type, is_nullable ]
        'id'        => [ 'int' ],
        'per_page'  => [ 'int' ],
        'page'      => [ 'int' ],
        'timeframe' => [ 'string' ],
        'order_by'  => [ 'array' ],
        'name'      => [ 'string' ],
    ];

    foreach ($fields as $fieldName => $fieldValue) {
        if (isset($fields_data[$fieldName])) {
            if (isset($fields_data[$fieldName][1])
                && $fields_data[$fieldName][1]
                && is_null($fieldValue)
            ) {
                $ret[$fieldName] = $fieldValue;
            } else {
                switch ($fields_data[$fieldName][0]) {
                    case 'bool':
                        $ret[$fieldName] = (bool)$fieldValue;
                        break;

                    case 'int':
                        $ret[$fieldName] = (int)$fieldValue;
                        break;

                    case 'float':
                        $ret[$fieldName] = (float)$fieldValue;
                        break;

                    case 'string':
                        $ret[$fieldName] = (string)$fieldValue;
                        break;

                    case 'array':
                        $ret[$fieldName] = (array)$fieldValue;
                        break;

                    default:
                        break;
                }
            }
        }
    }

    return $ret;
}

/**
 * It sorts multidimensional array from defined key.
 *
 * @author Nikola Nikolić <rogers94kv@gmail.com>
 * @param  array  $arrayToSort   Array that is sorted.
 * @param  string $keyName       Key name that is used for sorting
 * @param  int    $sortDirection Sorting direction.
 * @return void
 */
function sortMultidimensionalArrayByKeyName(
    array &$arrayToSort,
    string $keyName,
    int $sortDirection = SORT_ASC
) {
    // Get array columns. 
    $columns = array_column($arrayToSort, $keyName);

    // Sort array.
    array_multisort($columns, $sortDirection, $arrayToSort);
}

/**
 * It converts camel to kebab case.
 *
 * @author Nikola Nikolić <rogers94kv@gmail.com>
 * @param  string $str String to be converted.
 * @return string      Converted string.
 */
function fromCamelToKebabCase(string $str) {
    return strtolower(preg_replace('/([A-Z])/', '-$1', $str));
}

/**
 * It converts kebab to camel case.
 *
 * @author Nikola Nikolić <rogers94kv@gmail.com>
 * @param  string $str String to be converted.
 * @return string      Converted string.
 */
function fromKebabToCamelCase(string $str) {
    $ret = explode('-', $str);

    foreach ($ret as $index => &$item) {
        if ($index) {
            $item = ucfirst($item);
        }
    }

    return implode('', $ret);
}
