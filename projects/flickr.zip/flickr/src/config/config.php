<?php

// Project data.
define('PROJECT_NAME',      'Flickr Project');
define('PROJECT_API_URL',   'api/');

define('DEFAULT_LANG', 'en');

// Flickr's data.
define('FLICKR_API_URL', 'https://api.flickr.com/services/rest/?');
define('FLICKR_API_KEY', '__YOUR_API_KEY__');

// Message types.
define('MESSAGE_TYPE_ERROR',      1);
define('MESSAGE_TYPE_WARNING',    2);
define('MESSAGE_TYPE_SUCCESS',    3);
define('MESSAGE_TYPE_INFO',       4);

// Validation statuses.
define('VALIDATION_STATUS_ERROR',           1);
define('VALIDATION_STATUS_SUCCESS',         2);
define('VALIDATION_STATUS_INVALID_TYPE',    3);
define('VALIDATION_STATUS_MISSING_KEY',     4);

// Field options.
define('FIELD_OPTIONAL',    0);
define('FIELD_REQUIRED',    1);
