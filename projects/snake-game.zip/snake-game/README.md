# Snake game

Snake game in JavaScript using custom made sprites.

![snake-game-screenshot](screenshot.png)
