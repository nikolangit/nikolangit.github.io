<?php

require_once 'config.php';

$response = [
    'status' => STATUS_ERROR,
    'msg'    => 'API call is not valid.',
];

if (isset($_GET['url']) && $_GET['url']) {
    $urlArr = explode('/', $_GET['url']);

    $person1 = '';
    $person2 = '';

    if (isset($urlArr[1])) {
        $person1 = urlencode(strtolower($urlArr[1]));
    }

    if (isset($urlArr[2])) {
        $person2 = urlencode(strtolower($urlArr[2]));
    }

    $nameRegex = '/^[a-zA-Z]{3,}$/';

    if (!isset($urlArr[0]) && ($urlArr[0] != API_END_POINT)) {
        $response['msg'] = 'Invalid request.';

    } else if (!$person1 || !$person2) {
        $response['msg'] = 'You must enter persons name.';

    } else if (!preg_match($nameRegex, $person1) || !preg_match($nameRegex, $person2)) {
        $response['msg'] = 'You must enter persons name.';

    } else {
        $response['msg'] = 'Invalid response.';

        $curl = curl_init();

        $curlArray = [
            CURLOPT_URL            => 'https://love-calculator.p.rapidapi.com/getPercentage?fname=' . $person1 . '&sname=' . $person2,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING       => '',
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST  => 'GET',
            CURLOPT_HTTPHEADER => [
                'x-rapidapi-host: love-calculator.p.rapidapi.com',
                'x-rapidapi-key: ' . RAPID_API
            ],
        ];

        curl_setopt_array($curl, $curlArray);

        $apiResponse = json_decode(curl_exec($curl));

        curl_close($curl);

        if (!is_null($apiResponse)) {
            if (isset($apiResponse->message)) {
                $response['msg'] = $apiResponse->message;
            } else {
                $response = [
                    'status'  => STATUS_SUCCES,
                    'msg'     => $apiResponse->result,
                    'percent' => $apiResponse->percentage,
                ];
            }
        }
    }

}

header('Content-Type: application/json');
die(json_encode($response));
