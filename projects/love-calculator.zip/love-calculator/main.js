const API_END_POINT = 'api',
    STATUS_ERROR    = 0
;

const elms = {
        person1    : document.getElementById('person-1'),
        person2    : document.getElementById('person-2'),
        errorMsg   : document.getElementById('error-msg'),
        lovePercent: document.getElementById('love-percent'),
        loveMsg    : document.getElementById('love-msg'),
        btn        : document.getElementById('btn'),
        heartHolder: document.getElementsByClassName('heart-holder')[0]
    },
    regex = /^[a-zA-z]{3,}$/
;

elms.btn.onclick = function () {
    elms.heartHolder.dataset.active = '0';

    if (!elms.person1.value || !elms.person2.value) {
        elms.errorMsg.textContent = 'You must enter persons name.';

    } else if ((elms.person1.value.match(regex) == null) || (elms.person2.value.match(regex) == null)) {
        elms.errorMsg.textContent = 'You must enter valid name that only consits of letters and has to be more then 3.';

    } else {
        let api_path = API_END_POINT
                + '/' + elms.person1.value
                + '/' + elms.person2.value
            ,
            xhttp = new XMLHttpRequest()
        ;

        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                try {
                    let response = JSON.parse(this.responseText);

                    if (response.status == STATUS_ERROR) {
                        elms.errorMsg.textContent = response.msg;
                        elms.loveMsg.textContent  = '';

                    } else {
                        elms.errorMsg.textContent    = '';
                        elms.lovePercent.textContent = response.percent;
                        elms.loveMsg.textContent     = response.msg;
                    }
                    
                    elms.heartHolder.dataset.active = '1';

                } catch (e) {
                    return false;
                }
            }
        };
        xhttp.open('GET', api_path, true);
        xhttp.send();
    }

    elms.person1.focus();
}
