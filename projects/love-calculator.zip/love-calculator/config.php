<?php

define('RAPID_API',     '__YOUR_RAPID_API_KEY__');
define('API_END_POINT', 'calculate-love');

define('STATUS_ERROR',  0);
define('STATUS_SUCCES', 1);
