<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="index,follow">
    <meta name="author" content="Nikola Nikolić">
    <title>The Love Calculator</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <h1>The Love Calculator</h1>
    </header>

    <main>
        <div class="peoples-holder">
            <div class="form-field">
                <input type="text" id="person-1" placeholder="Person 1" autofocus>
            </div>

            <h2>loves</h2>

            <div class="form-field">
                <input type="text" id="person-2" placeholder="Person 2">
            </div>

            <div id="error-msg"></div>
        </div>

        <div class="heart-holder">
            <div class="heart"></div>

            <div class="love-info">
                <div class="love-percent-holder">
                        <span id="love-percent">0</span>%
                    </div>
                <div id="love-msg"></div>
            </div>
        </div>

        <button id="btn">
            <span>Calculate</span>
        </button>
    </main>

    <script src="main.js"></script>

</body>
</html>
