# Love calculator

Simple love calculator that uses [RapidAPI's service](https://rapidapi.com/).

# Configuration

Inside `config.php` replace `__YOUR_RAPID_API_KEY__` with your RapidAPI's key.
