<?php

require_once 'app/config.php';
require_once 'autoload.php';
