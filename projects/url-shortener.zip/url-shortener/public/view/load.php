<?php

header("Location: {$data['url']}");
